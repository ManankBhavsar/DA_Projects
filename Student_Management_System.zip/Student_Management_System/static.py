HOST = '127.0.0.1'
USER = 'root'
PASSWORD = "Mabm@131093"
