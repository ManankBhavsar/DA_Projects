import sys
import tkinter.ttk, tkinter.messagebox
from datetime import datetime, date
import DB
import mysql.connector as connection
import static as s

try:
    from tkinter import *
except ImportError as e:
    print(e)

try:
    from tkinter.ttk import *
except ImportError as e1:
    print(e1)

from tkcalendar import DateEntry


class App:
    First_Name = ""
    Last_Name = ""
    Phone_No = 0
    City = ""
    State = ""
    DOB1 = ""

    def __init__(self, master):
        self.master = master
        self.frame = Frame(self.master)
        self.frame.grid()

        self.main_lb = Label(self.master, text="Student Management System", background="Yellow")
        self.main_lb.grid(row=0, column=1, padx=10, pady=10, sticky=NW)

        self.lb_1 = Label(self.master, text="Enter First Name :", background="lightblue")
        self.lb_1.grid(row=1, column=0, padx=10, pady=10)

        self.txt_1 = Entry(self.master, width=25)
        self.txt_1.grid(row=1, column=1, padx=10, pady=10)

        self.lb_2 = Label(self.master, text="Enter Last Name :", background="lightblue")
        self.lb_2.grid(row=2, column=0, padx=10, pady=10)

        self.txt_2 = Entry(self.master, width=25)
        self.txt_2.grid(row=2, column=1, padx=10, pady=10)

        self.lb_3 = Label(self.master, text="Contact No :", background="lightblue")
        self.lb_3.grid(row=3, column=0, padx=10, pady=10)

        self.txt_3 = Entry(self.master, width=25)
        self.txt_3.grid(row=3, column=1, padx=10, pady=10)

        self.lb_4 = Label(self.master, text="Enter City :", background="lightblue")
        self.lb_4.grid(row=4, column=0, padx=10, pady=10)

        self.txt_4 = Entry(self.master, width=25)
        self.txt_4.grid(row=4, column=1, padx=10, pady=10)

        self.lb_5 = Label(self.master, text="Enter State :", background="lightblue")
        self.lb_5.grid(row=5, column=0, padx=10, pady=10)

        self.txt_5 = Entry(self.master, width=25)
        self.txt_5.grid(row=5, column=1, padx=10, pady=10)

        self.lb_6 = Label(self.master, text="Enter Date of Birth :", background="lightblue")
        self.lb_6.grid(row=6, column=0, padx=10, pady=10)

        self.dt_entry = DateEntry(self.master, locale='en_US', date_pattern='MM/dd/yyyy')
        self.dt_entry.grid(row=6, column=1, padx=10, pady=10)
        self.dt_entry.configure(width=22)

        style = Style(self.master)
        style.configure('W.TButton', font=('calibre', 10, 'bold'), foreground='red', borderwidth='4')
        self.bt_register = Button(self.master, text="Register", style='W.TButton', command=self.register_values)
        self.bt_register.grid(row=7, column=0, padx=10, pady=10, sticky=E)

        self.bt_update = Button(self.master, text="Update", style='W.TButton', command=self.update_value)
        self.bt_update.grid(row=7, column=1, padx=10, pady=10, sticky=W)

        self.bt_delete = Button(self.master, text="Delete", style='W.TButton', command=self.delete_values)
        self.bt_delete.grid(row=7, column=1, padx=100, pady=10, sticky=W)

        self.bt_clear = Button(self.master, text="Clear", style='W.TButton', command=self.clear_fields)
        self.bt_clear.grid(row=7, column=1, padx=200, pady=10, sticky=W)

        self.bt_show_all = Button(self.master, text="Show All", style='W.TButton', command=self.retrieve_value)
        self.bt_show_all.grid(row=7, column=1, padx=300, pady=10, sticky=E)

        self.lb_7 = Label(self.master, text="Please Select Record form below to Update or Delete:",
                          background="lightblue")
        self.lb_7.grid(row=8, column=0, padx=10, pady=10)

        self.tree_view = tkinter.ttk.Treeview(self.master, selectmode='browse')
        self.tree_view.grid(row=9, column=0, padx=10, pady=10, sticky=W)

        self.ver_scrollbar = tkinter.ttk.Scrollbar(self.master, orient="vertical", command="")
        self.ver_scrollbar.grid(row=9, column=0, padx=10, pady=10, sticky=E)

        self.tree_view.configure(xscrollcommand=self.ver_scrollbar.set)

        self.tree_view["columns"] = ("1", "2", "3", "4", "5", "6", "7")
        self.tree_view['show'] = 'headings'

        self.tree_view.column("1", width=90, anchor="nw")
        self.tree_view.column("2", width=90, anchor="nw")
        self.tree_view.column("3", width=90, anchor="nw")
        self.tree_view.column("4", width=90, anchor="nw")
        self.tree_view.column("5", width=90, anchor="nw")
        self.tree_view.column("6", width=90, anchor="nw")
        self.tree_view.column("7", width=90, anchor="nw")

        self.tree_view.heading("1", text="RollNo")
        self.tree_view.heading("2", text="First Name")
        self.tree_view.heading("3", text="Last name")
        self.tree_view.heading("4", text="City")
        self.tree_view.heading("5", text="State")
        self.tree_view.heading("6", text="Phone No")
        self.tree_view.heading("7", text="DOB")

        self.txt_8 = Entry(self.master)
        self.txt_8.grid(row=9, column=1, padx=300, pady=10, stick=W)

        self.bt_search = Button(self.master, text="Search", style='W.TButton', command="")
        self.bt_search.grid(row=9, column=1, padx=200, pady=10, sticky=E)

        self.bt_exit = Button(self.master, text="Exit", style='W.TButton', command=self.__exit__)
        self.bt_exit.grid(row=10, column=1, padx=200, pady=10, sticky=W)

        self.retrieve_value()

    def __exit__(self):
        sys.exit()

    def register_values(self):
        self.get_values()
        conn1 = connection.connect(host=s.HOST, user=s.USER, passwd=s.PASSWORD, use_pure=True)
        cur1 = conn1.cursor()

        obj = DB.db(cur1, conn1)
        obj.use_db()

        obj.insert_into_table(fn=App.First_Name, ln=App.Last_Name, city=App.City, state=App.State,
                              ph=App.Phone_No, dob=App.DOB1)

        obj.close_connection()
        self.retrieve_value()
        self.clear_fields()

    def delete_values(self):
        self.get_values()
        for i in self.tree_view.selection():
            x = self.tree_view.item(i)
            y = x['values'][0]
        conn1 = connection.connect(host=s.HOST, user=s.USER, passwd=s.PASSWORD, use_pure=True)
        cur1 = conn1.cursor()

        obj = DB.db(cur1, conn1)
        obj.use_db()

        obj.delete_from_table("RollNo", y)
        obj.select_table()

        obj.close_connection()
        self.retrieve_value()

    def retrieve_value(self):
        for i in self.tree_view.get_children():
            self.tree_view.delete(i)
        self.tree_view.clipboard_clear()
        data = []
        conn1 = connection.connect(host=s.HOST, user=s.USER, passwd=s.PASSWORD, use_pure=True)
        cur1 = conn1.cursor()

        obj = DB.db(cur1, conn1)
        obj.use_db()

        data = obj.select_table()
        for d in data:
            self.tree_view.insert('', END, values=d)

        obj.close_connection()

    def update_value(self):
        y = 0
        v1, v2, v3, v4, v5, v6 = self.get_values()
        dict1 = {"First_Name": str(v1), "Last_Name": str(v2), "Phone_No": v3, "City": str(v4), "State": str(v5)}

        for f in self.tree_view.selection():
            x = self.tree_view.item(f)
            y = x['values'][0]

        if y == 0:
            tkinter.messagebox.showwarning("showwarning", "Please Select row for update")
            sys.exit()
        else:
            conn1 = connection.connect(host=s.HOST, user=s.USER, passwd=s.PASSWORD, use_pure=True)
            cur1 = conn1.cursor()

            obj = DB.db(cur1, conn1)
            obj.use_db()

            for i, j in dict1.items():
                if j != "":
                    obj.update_table(i, j, "RollNo", int(y))

            obj.close_connection()
            self.retrieve_value()

    def clear_fields(self):
        self.txt_1.delete(0, END)
        self.txt_2.delete(0, END)
        self.txt_3.delete(0, END)
        self.txt_4.delete(0, END)
        self.txt_5.delete(0, END)
        self.dt_entry.set_date(date.today())

    def get_values(self):
        App.First_Name = self.txt_1.get()
        App.Last_Name = self.txt_2.get()
        App.Phone_No = self.txt_3.get()
        App.City = self.txt_4.get()
        App.State = self.txt_5.get()
        DOB = self.dt_entry.get()
        App.DOB1 = datetime.strptime(DOB, '%m/%d/%Y')
        App.DOB1 = App.DOB1.strftime('%Y-%m-%d')
        self.clear_fields()

        return App.First_Name, App.Last_Name, App.Phone_No, App.City, App.State, App.DOB1


def main():
    root = Tk()
    root.geometry('1700x800+0+0')
    root.resizable(True, True)
    root['background'] = "azure2"
    obj = App(root)
    root.mainloop()


if __name__ == '__main__':
    main()
