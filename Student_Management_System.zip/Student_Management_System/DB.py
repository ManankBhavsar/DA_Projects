import mysql.connector as connection
import static as s


class db:
    
    def __init__(self, cur1, conn1):
        self.cur = cur1
        self.conn = conn1

    def show_db(self):
        self.cur.execute("show databases")
        res = self.cur.fetchall()
        print(res)

    def create_db(self):
        self.cur.execute("create database Student_Management_System")

    def use_db(self):
        self.cur.execute("use Student_Management_System")

    def create_table(self):
        self.cur.execute("create table SMS (RollNo int(10) Auto_Increment Primary key, First_Name varchar(50)," +
                         " Last_Name varchar(50), City varchar(50), State varchar(50), Phone_No int(15), DOB date)")

    def delete_table(self):
        self.cur.execute("DROP TABLE SMS")

    def truncate_table(self):
        self.cur.execute("TRUNCATE TABLE SMS")

    def alter_table(self):
        self.cur.execute("ALTER TABLE SMS MODIFY COLUMN RollNo int(10) Auto_Increment Primary Key," +
                         " MODIFY COLUMN First_Name varchar(50);")

    def insert_into_table(self, fn, ln, city, state, ph, dob):
        sql = "insert into SMS (First_Name, Last_Name, City, State, Phone_No, DOB) VALUES" + \
              " ('{0}', '{1}', '{2}', '{3}', {4}, '{5}')".format(fn, ln, city, state, ph, dob)
        self.cur.execute(sql)

        self.conn.commit()

    def update_table(self, col_name, val, col_name1, val1):
        sql = f"UPDATE SMS SET {col_name} = '{val}' WHERE {col_name1} = {val1}"
        self.cur.execute(sql)
        self.conn.commit()

    def select_table(self):
        self.cur.execute("select * from SMS")
        res = self.cur.fetchall()
        return res

    def delete_from_table(self, field_value, search_value):
        self.cur.execute("DELETE FROM SMS WHERE {0}={1}".format(field_value, search_value))
        self.conn.commit()

    def close_connection(self):
        self.conn.close()


